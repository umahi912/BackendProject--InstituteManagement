from django.contrib import admin
from .models import StudentData,Student

# Register your models here.
admin.site.register(StudentData)
admin.site.register(Student)
